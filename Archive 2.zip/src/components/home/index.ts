export { default as HeroSection } from './HeroSection';
export { default as AboutSection } from './AboutSection';
export { default as ServicesSection } from './ServicesSection';
export { default as ProductSection } from './ProductSection';
export { default as TrainingSection } from './TrainingSection';