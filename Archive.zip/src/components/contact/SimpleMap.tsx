'use client';
import { useEffect, useRef, useState } from 'react';

interface SimpleMapProps {
  center?: [number, number];
  zoom?: number;
  popupText?: string;
}

const SimpleMap = ({
  center = [-7.9797, 112.6304],
  zoom = 15,
  popupText = "PT. Greenovate Energy Solutions<br />Jl. Soekarno Hatta, Malang"
}: SimpleMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (!isClient || !mapRef.current) return;

    // Clean up existing map instance
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    // Small delay to ensure DOM is ready
    const timer = setTimeout(() => {
      import('leaflet').then((L) => {
        if (!mapRef.current) return;

        // Clear any existing Leaflet data
        const container = mapRef.current as HTMLDivElement & { _leaflet_id?: number };
        if (container._leaflet_id) {
          delete container._leaflet_id;
        }
        container.innerHTML = '';

        try {
          // Create new map instance
          const map = L.map(container).setView(center, zoom);
          mapInstanceRef.current = map;

          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          }).addTo(map);

          const customIcon = L.icon({
            iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
            iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
          });

          L.marker(center, { icon: customIcon })
            .addTo(map)
            .bindPopup(popupText)
            .openPopup();

        } catch (error) {
          console.error('Error creating map:', error);
        }
      }).catch((error: Error) => {
        console.error('Error loading Leaflet:', error);
      });
    }, 100);

    // Cleanup function
    return () => {
      clearTimeout(timer);
      if (mapInstanceRef.current) {
        try {
          mapInstanceRef.current.remove();
        } catch (error) {
          console.error('Error removing map:', error);
        }
        mapInstanceRef.current = null;
      }
    };
  }, [isClient, center, zoom, popupText]);

  if (!isClient) {
    return (
      <div
        style={{ height: '400px', width: '100%', borderRadius: '0.375rem' }}
        className="bg-gray-200 flex items-center justify-center"
      >
        <div>Loading map...</div>
      </div>
    );
  }

  return (
    <div
      ref={mapRef}
      style={{ height: '400px', width: '100%', borderRadius: '0.375rem' }}
      className="bg-gray-200"
    />
  );
};

export default SimpleMap;