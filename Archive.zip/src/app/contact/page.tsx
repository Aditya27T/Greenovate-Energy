import { BannerSection, ContactForm, Map } from '@/components/contact';

export default function ContactPage() {
  return (
    <>
      <BannerSection title="CONTACT" />
      
      <section className="py-16 px-6 md:px-12">
        <div className="container mx-auto grid md:grid-cols-2 gap-8">
          {/* Contact Form */}
          <div>
            <ContactForm />
          </div>
          
          {/* Map */}
          <div className="h-[400px] w-full">
            <Map 
              center={[-7.9797, 112.6304]} 
              popupText="PT. Greenovate Energy Solutions<br />Jl. Soekarno Hatta, Malang"
              zoom={15}
            />
          </div>
        </div>
      </section>
    </>
  );
}