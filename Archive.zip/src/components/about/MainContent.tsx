import Image from 'next/image';

const MainContent = () => {
  return (
    <section className="py-16 px-6 md:px-12">
      <div className="container mx-auto grid md:grid-cols-2 gap-12">
        <div className="relative w-full aspect-[5/4]">
          <Image 
            src="/api/placeholder/500/400" 
            alt="Renewable Energy Team" 
            fill
            className="w-full h-auto rounded-lg object-cover"
          />
        </div>
        <div>
          <div className="border-l-2 border-primary pl-4 mb-6">
            <h2 className="text-lg font-medium text-gray-600">About Us</h2>
          </div>
          <h3 className="text-2xl md:text-3xl font-bold mb-6">More About <br />DiamondCut Motors Story</h3>
          <p className="text-gray-700 leading-relaxed">
            DiamondCut Motors is a prestigious car reseller that provides luxurious vehicles throughout Indonesia. It was founded in 1998 and has been growing exponentially ever since. DiamondCut Motors offers various renowned brands such as Porsche, Mercedes-Benz, Bugatti, and many others. A number of business owners and successful individuals have been customers of DiamondCut Motors, drawn by its cutting-edge service, timely delivery, and vehicle safety.
          </p>
        </div>
      </div>
    </section>
  );
};

export default MainContent;