import Link from 'next/link';
import Image from 'next/image';
import { getFeaturedProduct } from '@/data/products';

const ProductSection = () => {
  const featuredProduct = getFeaturedProduct();

  if (!featuredProduct) return null;

  return (
    <section className="py-16 px-6 md:px-12">
      <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
        <div className="relative w-full aspect-[5/4]">
          <Image 
            src="https://placehold.co/500x400/EEEEEE/3CB878?text=Product+Image" 
            alt="Product Image" 
            fill
            className="object-contain"
          />
        </div>
        <div>
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Our Product</h2>
          <p className="text-gray-600 mb-6">
            At Greenovate, we deliver tailored software solutions designed to optimize energy usage and reduce environmental impact. Our expert team can handle projects of any scale. We pride ourselves on customer service that exceeds what our competitors offer.
          </p>
          <Link 
            href="/products" 
            className="bg-primary hover:bg-secondary text-white font-medium py-2 px-6 rounded-md inline-block transition"
          >
            Beli Sekarang
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ProductSection;