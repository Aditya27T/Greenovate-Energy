import Image from 'next/image';

const MissionSection = () => {
  return (
    <section className="py-16 px-6 md:px-12">
      <div className="container mx-auto grid md:grid-cols-2 gap-12">
        <div className="relative w-full aspect-square">
          <Image 
            src="https://placehold.co/500x500/EEEEEE/3CB878?text=Team+Working" 
            alt="Team working together" 
            fill
            className="rounded-lg object-cover"
          />
        </div>
        <div>
          <div className="border-l-2 border-primary pl-4 mb-6">
            <h2 className="text-lg font-medium text-gray-600">Our Mission</h2>
          </div>
          <h3 className="text-2xl md:text-3xl font-bold mb-6">Exceeding Expectations Through<br />Integrity, Excellence, and<br />Continuous Improvement</h3>
          <p className="text-gray-700 leading-relaxed">
            At DiamondCut Motors, our mission is to exceed customer expectations by offering a diverse selection of high-quality new and pre-owned vehicles, along with unparalleled service and support. We are committed to building lasting relationships based on transparency, honesty, and trust, ensuring a seamless and enjoyable car-buying journey. Through continuous improvement and innovation, we embrace the latest technologies and trends to deliver superior value and satisfaction.
          </p>
        </div>
      </div>
    </section>
  );
};

export default MissionSection;